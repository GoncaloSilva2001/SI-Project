import os
from tkinter import *
from tkinter import filedialog
import hmac
import hashlib
import json
import tkinter as tk
from tkinter import messagebox
import base64
from cryptography.fernet import Fernet
import re
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes, padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend

global caminho_ficheiro


# Função para escolher o arquivo numa interface
def escolher():
    global caminho_ficheiro
    caminho = filedialog.askdirectory()
    arqui.set(caminho)
    caminho_ficheiro = caminho


# Funçao para sair
def sair():
    exit()


# Funçao para confirmar e continuar
def continuar():
    pasta = arqui.get()
    if pasta == "":
        escolher()

    database = open("baseDeDados.txt", "w")
    pathlist = os.listdir(pasta)
    BUF_SIZE = 65536  # para grandes ficheiros
    sha2 = hashlib.sha256()

    # percorrer cada ficheiro na directoria
    for file in pathlist:
        # Abrir o ficheiro em bytes
        with open(pasta + "/" + file, "rb") as f:
            while True:
                data = f.read(BUF_SIZE)
                if not data:
                    break
                sha2.update(data)
        f_hash = "{0}".format(sha2.hexdigest())
        # formatar a data em JSON
        ficheiro = {"nome": file, "sha256": f_hash}
        dados = json.dumps(ficheiro)
        # Escrever a data na database
        database.write(dados)
        print(dados)

    database.close()


def cifrar(senha):
    # Base de dados para cifrar mais a password que o utilizador quiser colocar
    base = "baseDeDados.txt"

    # Gerar o salt e a chave de cifra usando o algoritmo PBKDF2
    salt = b"\xc9c\xac\x80\xb1\xe4:\xb3eh\xcbb8\n\x1ez"
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend(),
    )
    chave = kdf.derive(senha.encode())
    # Iniciar a cifragem com a chave e o modo CBC
    iv = b"\xe6\xdc\x11;R\x8a\x12@M\xd6[\xa8\x9f\xba\xf7-"
    cipher = Cipher(algorithms.AES(chave), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()

    # Ler o conteúdo do arquivo
    with open(base, "rb") as f:
        conteudo = f.read()

    # Adicionar padding ao conteúdo
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    conteudo_pad = padder.update(conteudo) + padder.finalize()

    # Cifrar o conteúdo com o cifrador
    conteudo_cifrado = encryptor.update(conteudo_pad) + encryptor.finalize()

    # Escrever o conteúdo cifrado, o iv e o salt em um novo arquivo

    dados = {
        "iv": iv,
        "salt": salt,
        "conteudoFicheiro": conteudo_cifrado,
        "base": base,
        "chave": chave,
    }
    # Cria a base de dados cifrada

    return dados


def get_nomes(pasta):
    nomes_ficheiros = []
    for roots, dir, ficheiros in os.walk(pasta):
        for ficheiro in ficheiros:
            nomes_ficheiros.append(ficheiro)
    return nomes_ficheiros


# isto explode se houver mais diretorias dentro da diretoria escolhida


def remover_caracteres_nao_ascii(texto):
    texto_limpo = re.sub(r"[^\x00-\x7F]", "", texto)
    return texto_limpo


def hmac_sha512_do_ficheiro(key, base, iv, salt, conteudo_cifrado):
    block_size = 65536
    hmac_sha512 = hmac.new(key, digestmod=hashlib.sha512)
    sha512_hash = hashlib.sha512()
    nomedosficheiros = get_nomes(caminho_ficheiro)

    with open(base + ".json", "a") as json_file:
        for ficheiro in nomedosficheiros:
            with open(caminho_ficheiro + "/" + ficheiro, "rb") as file:
                while True:
                    data = file.read(block_size)
                    if not data:
                        break
                    data = salt + data
                    hmac_sha512.update(data)
                    sha512_hash.update(data)
                    hmac_digest = hmac_sha512.digest()
                    hmac_hex = hmac_sha512.hexdigest()
                    sha512_hex = sha512_hash.hexdigest()
                    hmac_good_stuf = {
                        "nome_dos_ficheiros": ficheiro,
                        "hmac_digest": hmac_digest.decode("latin-1"),
                        "hmac_hex": hmac_hex,
                        "sha_512_hex": sha512_hex,
                        "salt": salt.decode("latin-1"),
                        "iv": iv.decode("latin-1"),
                    }
                    json.dump(hmac_good_stuf, json_file)
                    json_file.write("\n")


def verificar_integridade():
    key = "1223"
    data = cifrar(key)
    print("verify senha:", key)
    chave = data["chave"]
    base = data["base"]
    salt = data["salt"]
    iv = data["iv"]
    block_size = 65536
    hmac_sha512 = hmac.new(chave, digestmod=hashlib.sha512)
    sha512_hash = hashlib.sha512()

    nomedosficheiros = get_nomes(caminho_ficheiro)
    nome_arquivo = "baseDeDados.txt.json"

    with open(nome_arquivo, "r") as file:
        basededados = json.load(file)

    resultados = []
    nova_base_dados = {}

    for ficheiro in nomedosficheiros:
        with open(caminho_ficheiro + "/" + ficheiro, "rb") as file:
            while True:
                data = file.read(block_size)
                if not data:
                    break
                data = salt + data
                hmac_sha512.update(data)
                sha512_hash.update(data)
                hmac_digest = hmac_sha512.digest()
                hmac_hex = hmac_sha512.hexdigest()
                sha512_hex = sha512_hash.hexdigest()
                hmac_good_stuf = {
                    "nome_dos_ficheiros": ficheiro,
                    "hmac_digest": hmac_digest.decode("latin-1"),
                    "hmac_hex": hmac_hex,
                    "sha_512_hex": sha512_hex,
                    "salt": salt.decode("latin-1"),
                    "iv": iv.decode("latin-1"),
                }
        # COMPARAÇAO DE UMA BASE DE DADOS E CIFRAR COM UMA NOVA SE UM DADOS FOR LTERADO
        if hmac_good_stuf != basededados:
            resultados.append(f"O arquivo {ficheiro} foi alterado.")
            for ficheiro in basededados:
                nova_base_dados[ficheiro] = basededados[ficheiro]
        else:
            resultados.append(f"O arquivo {ficheiro} não foi alterado.")
    # Verifica se há arquivos alterados
    if nova_base_dados:
        nova_base_dados_bytes = json.dumps(nova_base_dados).encode("utf-8")
        sha512_hash.update(nova_base_dados_bytes)
        newDb = sha512_hash.digest()

        # Cifra a nova base de dados com a senha usando a biblioteca cryptography
        with open("newDb.txt", "wb") as file:
            file.write(newDb)

        print("A nova base de dados foi criada e cifrada com sucesso.")

    return resultados


################EXit


def pass_cifrar(event=None):
    janela_cifrar = Toplevel()
    janela_cifrar.title("Palavra pass")

    def chamar_hmac_sha512(senha):
        print("senha ", senha)
        dados = cifrar(senha)
        print(senha == "1223")
        iv = dados["iv"]
        salt = dados["salt"]
        conteudo_cifrado = dados["conteudoFicheiro"]
        base = dados["base"]
        chave = dados["chave"]
        hmac_sha512_do_ficheiro(chave, base, iv, salt, conteudo_cifrado)

    campo_senha = Entry(janela_cifrar, width=40)
    campo_senha.pack()
    campo_senha.focus_set()

    botao_cifrar = Button(
        janela_cifrar,
        text="Cifrar",
        command=lambda: chamar_hmac_sha512(campo_senha.get()),
    )
    botao_cifrar.pack()


def popup_help():
    messagebox.showinfo(
        "Ajuda",
        "1-Botão Escolher: Serve para selecionar um arquivo que esteja no seu computador;\n"
        "2-Botão Continuar: Este botão faz com que se calcule o sha256 dos ficheiros do arquivo selecionado e guarda-os na Base de Dados juntamente com o nome do respetivo ficheiro;\n"
        "3-Botão Cifrar BD: Irá pedir uma password ao utilizador esta depois será usado um algoritmo de derivação de chaves de cifra seguro, juntamente com um salt;\n"
        "4-Botão Integridade: Verifica se o file foi alterado ou não e se na verdade for cria uma nova base de dados com a nova informação cifrada.",
    )


# Funcão Interface Para Apresentação File Alterado
def integridade():
    resultados = verificar_integridade()
    print(resultados)
    janela = Tk()
    janela.title("Verificação de Integridade")
    frame = Frame(janela)
    frame.pack(pady=10)

    lista_resultados = Listbox(frame, width=60)
    lista_resultados.pack(side=LEFT, fill=BOTH)

    scrollbar = Scrollbar(frame)
    scrollbar.pack(side=RIGHT, fill=BOTH)

    lista_resultados.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=lista_resultados.yview)

    for resultado in resultados:
        lista_resultados.insert(END, resultado)


# Comandos para iniciar a interface
root = Tk()
root.title("Estou te a ver!")
root.resizable(width=FALSE, height=FALSE)  # Não deixa alterar o tamanho
root.geometry("450x200")  # Tamanho da interface

# Interface(botões, labels, etc)
arqui = StringVar()
Label(root, textvariable=arqui, background="#ADD8E6").place(x=20, y=20)
but1 = Button(root, text="Escolher", command=escolher, activebackground="#A9A9A9")
but1.place(x=268, y=150)
but2 = Button(root, text="Continuar", command=continuar)
but2.place(x=330, y=150)
but3 = Button(root, text="Sair", command=sair)
but3.place(x=400, y=150)
but4 = Button(root, text="Cifrar BD", command=pass_cifrar)  # (arquivo)
but4.place(x=20, y=150)
but5 = Button(root, text="Help", command=popup_help)
but5.place(x=90, y=150)
but6 = Button(root, text="Integridade", command=integridade)
but6.place(x=180, y=150)
root.mainloop()